clc;
clear;
close all;
q=qrandstream('sobol',2,'Skip',1e3,'Leap',1e2);
U1=qrand(q,100);
U2=qrand(q,200);
scatter(U1(:,1),U1(:,2))
L=U1(:,1);n1=length(L); X1=zeros(n1,1);

Type_distribution='uniform';
switch Type_distribution
   case'uniform'
       b1=1; b2=2;
       for i=1:n1 
           X1(i)=(b2-b1)*L(i)+1;
       end
       
    case'normal'
        u1 = U1(:,3);
        u2 = U1(:,5);
        y= (-2*log(u1)).^0.5.*sin(2*pi*u2);
        figure(4);
        hist(y,11);    
        figure(2);
        normplot(y);   
       [muhat,sigmahat,muci,sigmaci]= normfit(y); 
       [h,sig,ci]= ttest(y,muhat);
        X2=27.4+7.672*y;
       
    case'lognormal'
        u1 = U1(:,7);
        u2 = U1(:,9);
        y=(-2*log(u1)).^0.5.*sin(2*pi*u2);
        figure(4);
        hist(y,11);    
        figure(2);
        normplot(y);   
       [muhat,sigmahat,muci,sigmaci]=normfit(y); 
       [h,sig,ci]= ttest(y,muhat);
       m=20;v=36;
       mu=log((m^2)/sqrt(v+m^2));
       sigma=sqrt(log(v/(m^2)+1));
       a=mu+sigma*y;
       X3=exp(a);
end
        