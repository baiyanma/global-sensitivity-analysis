clear,clc
data1=xlsread('sample_1');
data2=xlsread('sample_2');
Type_slope='example2';

switch Type_slope
     case'example1'
     n1=length(data1(:,1));
     a=zeros(n1,1);b=zeros(n1,1);d=zeros(n1,1);p=zeros(n1,1);
     q=zeros(n1,1);x0=zeros(n1,1);FS1=zeros(n1,1);
     for k=1:n1
     c=data1(k,1);phi=data1(k,2)*pi/180;gama=data1(k,3);theta=data1(k,4)*pi/180;H=data1(k,5);
     a(k)=gama*H*tan(phi)+2*c;
     b(k)=-gama*H^2*cot(theta)*tan(phi);
     d(k)=2*c*H^2;
     p(k)=gama*H^2;
     q(k)=gama*H^3*cot(theta);
     x0(k)=q(k)/p(k)+sqrt((p(k)*d(k)-b(k)*q(k))/(a(k)*p(k))+q(k)^2/p(k)^2);
     FS1(k)=(a(k)*x0(k)^2+b(k)*x0(k)+d(k))/(p(k)*x0(k)+q(k));
     end  
     case'example2'
     gamma_w=9.81; kh=0.2;kv=kh/2;
     n2=length(data2(:,1));FS2=zeros(n2,1);
     for k=1:n2;
     c=data2(k,1); phi=data2(k,2)*pi/180;gamma=data2(k,3);gamma_sat=data2(k,4);theta=data2(k,5)*pi/180;
     H=data2(k,6);m=data2(k,7);h=m.*H; 
     FS2(k)=((gamma.*(H-h).*sin(theta)+gamma_sat.*h.*cos(theta)).*((1-kv).*cos(theta)-kh.*sin(theta)).*tan(phi)+c)./((gamma.*(H-h).*cos(theta)+gamma_sat.*h.*... 
       cos(theta)).*((1-kv).*sin(theta)+kh.*cos(theta))+gamma_w.*h.*sin(theta).*sin(theta));
     end
end

% illustration: c is the cohesion, phi is the internal friction angle, gama is the natural unit weight, gama_sat is the saturated unit weight, 
% gama_w is the unit weight of water, theta is the slope angle, H is the height of slope. the rest symbols are the same as in the paper.       
 
