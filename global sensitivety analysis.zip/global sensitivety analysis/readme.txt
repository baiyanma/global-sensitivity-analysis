the description are as follows:
1. the samples of geotechnical parameters are simulated by sample.m flie based on Matlab software. the geotechnical parameters following a certain distribution chose the correspongidng type_distribution, and the mean value and the coefficient must be known.

2. the output response of the safety factor are calcualted by output_response.m file based on Matlab software. two testing data sample_1 and sample_2 are included in the file.

3. the predictive values of the safety factor are calcualted by the lars.zip file package based on R software. it is worth to note that this algorithm is obtained from Efron et.al.(2004). the more details are listed in: https://CRAN.R-project.org/package=lars.